// Generated file. Do not edit!
package org.jraf.klibperipage
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.0.0-SNAPSHOT"
